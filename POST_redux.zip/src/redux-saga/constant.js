export const BASE_URL = "http://localhost:3001";

export const GET_PRODUCT_API = "/posts";
export const POST_PRODUCT_API = "/posts";
export const PUT_PRODUCT_API = "/posts/"; //+id
export const DELETE_PRODUCT_API = "/posts/"; //+id
